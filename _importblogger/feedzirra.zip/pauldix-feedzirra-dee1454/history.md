# 0.1.1

- make FeedEntries enumerable (patch by Daniel Gregoire)

# 0.1.0

- lower builder requirement to make it rails-3 friendly
